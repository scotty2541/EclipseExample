#include <stdio.h>

void OtherFunction() {
	puts("testOut");
}
