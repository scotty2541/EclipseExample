#include <iostream>
using namespace std;

extern "C" void OtherFunction();

int main(int argc, char **argv) {
	cout << "Hello world";
	OtherFunction();
	return 0;
}
