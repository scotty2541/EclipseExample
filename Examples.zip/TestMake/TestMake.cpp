#include <stdio.h>


extern "C" void OtherFunction();

int main(int argc, char **argv) {
	puts("Hello World");
	OtherFunction();
	return 0;
}
