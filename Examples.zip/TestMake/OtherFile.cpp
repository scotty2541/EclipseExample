#include <stdio.h>

extern "C" void OtherFunction();

void OtherFunction() {
	puts("Hello Other World");
}
